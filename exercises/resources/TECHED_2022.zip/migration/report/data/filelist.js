var main_filelist = [
    {
        "name": "db/TechEd2022,/db/src/BASEKETANALYSIS_CALCULATE.hdbcalculationview",
        "pkgOnlyName": "hEd2022,/db/src/BASEKETANALYSIS_CALCULATE.hdbcalculationview",
        "ext": "hdbcalculationview",
        "container": "db",
        "index": 0
    },
    {
        "name": "db/TechEd2022,/db/src/COMBINESOURCESFORBASKETANALYSIS.hdbcalculationview",
        "pkgOnlyName": "hEd2022,/db/src/COMBINESOURCESFORBASKETANALYSIS.hdbcalculationview",
        "ext": "hdbcalculationview",
        "container": "db",
        "index": 1
    },
    {
        "name": "db/src/BasketAnalysis/BASEKETANALYSIS_CALCULATE.hdbcalculationview.properties",
        "pkgOnlyName": "/BasketAnalysis/BASEKETANALYSIS_CALCULATE.hdbcalculationview.properties",
        "ext": "properties",
        "container": "db",
        "index": 2
    },
    {
        "name": "db/src/BasketAnalysis/COMBINESOURCESFORBASKETANALYSIS.hdbcalculationview.properties",
        "pkgOnlyName": "/BasketAnalysis/COMBINESOURCESFORBASKETANALYSIS.hdbcalculationview.properties",
        "ext": "properties",
        "container": "db",
        "index": 3
    }
];