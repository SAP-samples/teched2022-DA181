var main_filedata = {
    "TechEd2022,/db/src/BASEKETANALYSIS_CALCULATE.hdbcalculationview": {
        "container": "db",
        "fileIndex": 0
    },
    "TechEd2022,/db/src/COMBINESOURCESFORBASKETANALYSIS.hdbcalculationview": {
        "container": "db",
        "fileIndex": 1
    },
    "src/BasketAnalysis/BASEKETANALYSIS_CALCULATE.hdbcalculationview.properties": {
        "container": "db",
        "fileIndex": 2
    },
    "src/BasketAnalysis/COMBINESOURCESFORBASKETANALYSIS.hdbcalculationview.properties": {
        "container": "db",
        "fileIndex": 3
    }
};